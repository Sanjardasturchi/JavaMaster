create function get_max_suplied_product_name() returns character varying
    language plpgsql
as
$$
declare
    p_id varchar;
    p_name varchar;
begin
    select pid,sum(qty) as sum_qty into p_id
    from sp
    group by(pid)
    order by sum_qty desc
    limit 1;

    select pname into p_name from p where pid = p_id;

    return p_name  ;
end;$$;

alter function get_max_suplied_product_name() owner to postgres;

