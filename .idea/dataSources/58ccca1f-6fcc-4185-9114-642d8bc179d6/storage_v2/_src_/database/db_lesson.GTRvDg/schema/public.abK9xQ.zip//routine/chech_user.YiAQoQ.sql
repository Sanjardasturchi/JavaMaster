create function chech_user(u_login character varying, u_pasword character varying) returns boolean
    language plpgsql
as
$$
declare
    result int;
begin
     select id into result from profile p where p.login=$1 and p.password=$2;
     if result isnull then
         return false;
     end if;

     return true;

end;$$;

alter function chech_user(varchar, varchar) owner to postgres;

