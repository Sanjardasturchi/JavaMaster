create function login(login_in character varying, password_in character varying) returns boolean
    language plpgsql
as
$$
declare
    p_exists bool;
begin

    select (p.password = password_in) into p_exists
    from profile p
    where p.login = login_in;

    return p_exists  ;
end;$$;

alter function login(varchar, varchar) owner to postgres;

