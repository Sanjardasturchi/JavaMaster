create function count_of_qty(sidd character varying) returns integer
    language plpgsql
as
$$
declare
--     result int;
begin
    return (select count(qty) from sp where sp.sid=sidd);

end;$$;

alter function count_of_qty(varchar) owner to postgres;

