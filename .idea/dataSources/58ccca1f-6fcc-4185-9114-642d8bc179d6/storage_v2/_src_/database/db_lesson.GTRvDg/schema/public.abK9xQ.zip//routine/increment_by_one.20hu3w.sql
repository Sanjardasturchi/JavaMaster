create function increment_by_one(param1 integer) returns integer
    language plpgsql
as
$$
declare
    result int;
begin
    select param1+1 into result;
    return result;
end;$$;

alter function increment_by_one(integer) owner to postgres;

